w96.FS.rm("C:/system/local/bin/reboot");
w96.FS.cpfile("C:/system/boot/apps/hello", "C:/system/local/bin/reboot")