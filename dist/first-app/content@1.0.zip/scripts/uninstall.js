w96.sys.reg.deregisterApp("explorer");
w96.sys.reg.deregisterApp("textpad");
w96.sys.reg.deregisterApp("dyk");